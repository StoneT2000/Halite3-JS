const mining = require('./mining');
const movement = require('./movement');
const search = require('./search')

module.exports = {
  mining,
  movement,
  search,
};
