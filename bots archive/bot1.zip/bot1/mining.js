module.exports = {
  //returns target location
  search(){
    
  }
  
  
}